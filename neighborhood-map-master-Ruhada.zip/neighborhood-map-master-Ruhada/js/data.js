/* Model Data */

var locations = [
    {
        title: 'Prishtina',
        location: {
            lat: 42.667542,
            lng: 21.166191
        }
    },
    {
        title: 'Prizren',
        location: {
            lat: 42.215260,
            lng: 20.741474
        }
    },
    {
        title: 'Gjilan',
        location: {
            lat: 42.463486,
            lng: 21.468315
        }
    },
    {
        title: 'UBT College',
        location: {
            lat: 42.648199,
            lng: 21.160201
        }
    },
    {
        title: 'Bill Clinton',
        location: {
            lat: 42.65367,
            lng: 21.1525102
        }
    },
    {
        title: 'Albi Mall',
        location: {
            lat: 42.6329337,
            lng: 21.1504727
        }
    }
];
